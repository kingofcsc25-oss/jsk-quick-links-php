// Inject a div so the localhost dashboard knows the extension is installed
const extensionDetector = document.createElement('div');
extensionDetector.id = 'pan-extension-active';
extensionDetector.style.display = 'none';

if (document.documentElement) {
    document.documentElement.appendChild(extensionDetector);
} else {
    document.addEventListener('DOMContentLoaded', () => {
        document.body.appendChild(extensionDetector);
    });
}
