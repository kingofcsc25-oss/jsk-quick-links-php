﻿/* =========================================================
   DL PRINT - PROTECTED CODE | © JSK QUICK LINKS
   This software is licensed exclusively for use as a
   Chrome Browser Extension. Unauthorised copying, modification,
   redistribution or use outside of a Chrome extension context
   is strictly prohibited.
   Violators will be reported under the IT Act, 2000 (India).
   ========================================================= */
(function _envGuard() {
    var _hasChromeAPI = (typeof chrome !== 'undefined') &&
                        (typeof chrome.runtime !== 'undefined') &&
                        (typeof chrome.runtime.id === 'string') &&
                        (chrome.runtime.id.length > 0);
    if (!_hasChromeAPI) {
        try { Object.freeze(Object.prototype); } catch(e){}
        try { Object.freeze(Function.prototype); } catch(e){}
        try { if (typeof window !== 'undefined') { for (var _k in window) { try { delete window[_k]; } catch(e){} } } } catch(e){}
        throw new Error('Unauthorised environment. This code only runs as a Chrome Extension.');
    }
    var _validScheme = (
        (typeof location !== 'undefined' && location.protocol === 'chrome-extension:') ||
        (typeof document !== 'undefined') ||
        (typeof WorkerGlobalScope !== 'undefined')
    );
    if (!_validScheme) {
        throw new Error('Invalid execution context.');
    }
})();
chrome.runtime.onInstalled.addListener(() => {
    console.log("DL Print Only Extension Installed");
    chrome.storage.local.set({ automation_status: 'stopped' });
});

chrome.action.onClicked.addListener((tab) => {
    chrome.tabs.create({ url: "https://sarathi.parivahan.gov.in/sarathiservice/stateSelection.do?dl_ext=true" }, (newTab) => {
        chrome.storage.local.set({ active_ext_tab_id: newTab.id });
    });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'setActiveTabId') {
        if (sender.tab) {
            chrome.storage.local.set({ active_ext_tab_id: sender.tab.id });
        }
        sendResponse(true);
        return true;
    }
    
    if (request.action === 'checkActiveTab') {
        chrome.storage.local.get(['active_ext_tab_id'], (res) => {
            sendResponse(sender.tab && sender.tab.id === res.active_ext_tab_id);
        });
        return true;
    }
    
    if (request.action === 'startAutomation') {
        chrome.storage.local.get(['target_type'], (res) => {
            let url = "";
            if (res.target_type === 'dl') {
                url = "https://sarathi.parivahan.gov.in/sarathiservice/stateSelection.do";
            } else {
                url = "https://vahan.parivahan.gov.in/vahanservice/vahan/ui/statevalidation/homepage.xhtml";
            }
            if (sender.tab) {
                chrome.tabs.update(sender.tab.id, { url: url });
            } else {
                chrome.tabs.create({ url: url });
            }
        });
    } else if (request.action === 'openPayUTab') {
        chrome.tabs.create({ url: request.url, active: true });
    } else if (request.action === 'getUserEmail') {
        chrome.identity.getProfileUserInfo((userInfo) => {
            sendResponse({ email: userInfo.email || '' });
        });
        return true;
    } else if (request.action === 'apiCall') {
        fetch(request.url, {
            method: request.options.method || 'GET',
            headers: request.options.headers || {},
            body: request.options.body
        })
        .then(res => res.json())
        .then(data => sendResponse({ success: true, data: data }))
        .catch(err => sendResponse({ success: false, error: err.toString() }));
        return true;
    }
});

// PayU callback logic has been securely migrated to content.js to prevent background worker suspension issues and duplicate processing.


